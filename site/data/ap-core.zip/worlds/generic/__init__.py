from typing import NamedTuple, Union
from typing_extensions import deprecated
import logging

from BaseClasses import Item, Tutorial, ItemClassification

from ..AutoWorld import InvalidItemError, World, WebWorld
from NetUtils import SlotType


class GenericWeb(WebWorld):
    advanced_settings = Tutorial('Advanced YAML Guide',
                                 'A guide to reading YAML files and editing them to fully customize your game.',
                                 'English', 'advanced_settings_en.md', 'advanced_settings/en',
                                 ['alwaysintreble', 'Alchav'])
    commands = Tutorial('Archipelago Server and Client Commands',
                        'A guide detailing the commands available to the user when participating in an Archipelago session.',
                        'English', 'commands_en.md', 'commands/en', ['jat2980', 'Ijwu'])
    mac = Tutorial('Archipelago Setup Guide for Mac', 'A guide detailing how to run Archipelago clients on macOS.', 
                   'English', 'mac_en.md','mac/en', ['Bicoloursnake', 'silasary'])
    plando = Tutorial('Archipelago Plando Guide', 'A guide to understanding and using plando for your game.',
                      'English', 'plando_en.md', 'plando/en', ['alwaysintreble', 'Alchav'])
    setup = Tutorial('Getting Started',
                     'A guide to setting up the Archipelago software, and generating, hosting, and connecting to '
                     'multiworld games.',
                     'English', 'setup_en.md', 'setup/en', ['alwaysintreble'])
    triggers = Tutorial('Archipelago Triggers Guide', 'A guide to setting up and using triggers in your game settings.',
                        'English', 'triggers_en.md', 'triggers/en', ['alwaysintreble'])
    other_games = Tutorial('Other Games and Tools',
                           'A guide to additional games and tools that can be used with Archipelago.',
                           'English', 'other_en.md', 'other/en', ['Berserker'])
    tutorials = [setup, mac, commands, advanced_settings, triggers, plando, other_games]


class GenericWorld(World):
    game = "Archipelago"
    topology_present = False
    item_name_to_id = {
        "Nothing": -1
    }
    location_name_to_id = {
        "Cheat Console": -1,
        "Server": -2
    }
    hidden = True
    web = GenericWeb()

    def generate_early(self):
        self.multiworld.player_types[self.player] = SlotType.spectator  # mark as spectator

    def create_item(self, name: str) -> Item:
        if name == "Nothing":
            return Item(name, ItemClassification.filler, -1, self.player)
        raise InvalidItemError(name)
